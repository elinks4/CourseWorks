namespace Teht2
{
    public interface IPlayer
    {
         int Score {get; set;}
    }
}