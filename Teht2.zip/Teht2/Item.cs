using System;

namespace Teht2
{
    public class Item
    {
        public Guid Id { get; set; }
        public int Level { get; set; }
    }
}