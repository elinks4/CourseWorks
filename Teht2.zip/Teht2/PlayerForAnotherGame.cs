using System;
using System.Collections.Generic;
using System.Linq;
namespace Teht2
{
    public class PlayerForAnotherGame : IPlayer
    {
        public int Score { get; set; }


        









    }
}