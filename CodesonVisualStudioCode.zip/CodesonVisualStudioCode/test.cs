using System;

namespace CodesonVisualStudioCode
{
    public class test
    {
        
    }


    public static class ExtensionExamples{

        public static void PrintString(this string s){

            Console.WriteLine(s);

        }
    

    }











}