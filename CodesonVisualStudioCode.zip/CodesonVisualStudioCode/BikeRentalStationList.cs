namespace CodesonVisualStudioCode
{
    public class BikeRentalStationList
    {

        public stations[] stations {get; set;}



    }



    public class stations{

        public int bikesAvailable{get; set;}
        public string name{get; set;}
    }
}