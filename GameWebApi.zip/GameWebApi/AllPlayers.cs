using System.Collections.Generic;

namespace GameWebApi
{
    public class AllPlayers// : IAllPlayers
    {
        


    //   public List<Player> play {get; set;}

       public List<Player> play = new List<Player>();



    }
}