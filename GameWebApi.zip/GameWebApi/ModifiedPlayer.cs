namespace GameWebApi
{
    public class ModifiedPlayer
    {
         public int Score { get; set; }
    }
}