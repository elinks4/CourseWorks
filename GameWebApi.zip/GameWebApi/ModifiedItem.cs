namespace GameWebApi
{
    public class ModifiedItem
    {
         public int Level { get; set; }
        
    }
}